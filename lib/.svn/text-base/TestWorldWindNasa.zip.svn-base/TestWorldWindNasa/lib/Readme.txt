@Victor Guana
--------------------------------------------------------------------------------------
1. Configuring the project

Import the jars in the buildpath of the project:

gdal.jar
worldwind.jar
worldwindx.jar

Depending on the OS architecture import the 32|64 bits libraries in the buildpath

gluegen-rt.jar
jogl.jar

--------------------------------------------------------------------------------------
2. Configuring the JVM

Copy the dlls for your OS architecture into the JAVA_PATH/jre/bin

gluegen-rt.dll
jogl_awt.dll
jogl_cg.dll
jogl.dll


Copy the jars for your OS architecture into the JAVA_PATH/jre/lib/ext
gluegen-rt.jar
jogl.jar